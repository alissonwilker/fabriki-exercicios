import java.util.List;

import xadrez.Xadrez;

public class TestUtil {
    public static List<String> procurarMovimentosXequeMateEmUmLance(Xadrez xadrez) {
        // TODO Auto-generated method stub
        return null;
    }

}
